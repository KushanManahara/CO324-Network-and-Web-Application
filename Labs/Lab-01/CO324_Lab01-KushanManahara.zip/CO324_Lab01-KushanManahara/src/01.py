from dataclasses import dataclass

@dataclass
class DataclassCard:
    rank : str
    suit : str

qh = DataclassCard('Q', "h")
print(qh)