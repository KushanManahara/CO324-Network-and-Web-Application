from dataclasses import dataclass
from typing import IO, Dict, List

file = open("E:\SEM 05\CO324-Network and Web Application\Labs\Lab-01\CO324_Lab01-KushanManahara\student_registrations.csv", "r")

@dataclass
class Student:
    """A student's course registration details"""
    given_name: str
    surname: str
    registered_courses: List[str]

@dataclass
class Deck:
    lines : List[Student]



# # Example object:
# s1 = Student("Saman","Silva",["CO324","CO321","CO325"])